const express = require('express');
const app = express();

app.use(express.json());

app.get('/', (req, res) => {
  res.send('Сервер жұмыс істеп тұр!');
});

// Серверді тек егер файл тікелей іске қосылса ғана ашамыз
if (require.main === module) {
  app.listen(3000, () => {
    console.log('Server 3000 портында жұмыс істеп тұр');
  });
}

module.exports = app; // Тест үшін экспорттаймыз
