// tests/sample.test.js
test('2 + 2 = 4 болу керек', () => {
  expect(2 + 2).toBe(4);
});
